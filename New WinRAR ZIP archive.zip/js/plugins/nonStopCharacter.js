﻿(function() {
	Game_CharacterBase.prototype.isNearTheScreen = function() {
		return true;
	};
})();